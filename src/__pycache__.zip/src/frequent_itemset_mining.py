
from parsoda_costantino.analysis.sequential_fp_growth import SequentialFPGrowth

from parsoda.model.driver.parsoda_pycompss_driver import ParsodaPyCompssDriver
from parsoda_costantino.common.social_data_app import SocialDataApp
from parsoda.function.filtering.is_geotagged import IsGeotagged
from parsoda.function.filtering import IsInRoI
from parsoda.function.filtering import IsInPlace
from parsoda_costantino.mapping.find_PoIs import FindPoIs
from parsoda_costantino.parsing.file_reader_crawler import FileReaderCrawler
from parsoda_costantino.reduction.reduce_by_trajectories import ReduceByTrajectories
from parsoda_costantino.visualization.sort_sequential_frequent_itemsets import SortSequentialFrequentItemsets
import sys

if __name__ == '__main__':

    # driver = ParsodaSingleCoreDriver()
    # driver = ParsodaMultiCoreDriver(4)
    # driver = ParsodaPySparkDriver(SparkConf().setMaster("local[*]"))
    driver = ParsodaPyCompssDriver()

    app = SocialDataApp("Sequential Analysis Frequent Itemset Mining", driver)

    app.set_crawlers([
        FileReaderCrawler("resources/flickr100k.json")
    ])
    app.set_filters([
        IsInPlace(12.492, 41.890, 10000),
        IsInRoI("resources/RomeRoIs.kml")
    ])
    app.set_mappers([
        FindPoIs("resources/RomeRoIs.kml")
    ])

    r_function = ReduceByTrajectories()
    app.set_reducer(r_function, None)

    a_functions = SequentialFPGrowth()
    a_params = "-min_support 30 -association_rules yes -ass_rules_min_confidence 0.02"
    app.set_analysis_function(a_functions, a_params)

    v_functions = SortSequentialFrequentItemsets()
    v_params = "-mode descending -association_rules yes"
    app.set_visualization_function(v_functions, v_params)

    app.execute()
