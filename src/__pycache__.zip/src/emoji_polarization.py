from datetime import date

from pyspark import SparkContext, SparkConf

from parsoda import SocialDataApp
from parsoda.function.analysis.gap_bide_analysis import GapBIDE
from parsoda.function.analysis.two_factions_polarization import TwoFactionsPolarization
from parsoda.function.crawling.local_file_crawler import LocalFileCrawler
from parsoda.function.crawling.parsing.flickr_parser import FlickrParser
from parsoda.function.crawling.parsing.twitter_parser import TwitterParser
from parsoda.function.filtering import IsGeotagged, IsInPlace, IsInRoI, HasEmoji
import sys

from parsoda.function.mapping.classify_by_emoji import ClassifyByEmoji
from parsoda.function.mapping.find_poi import FindPoI
from parsoda.function.reduction.reduce_by_emoji_polarity import ReduceByEmojiPolarity
from parsoda.function.reduction.reduce_by_trajectories import ReduceByTrajectories
from parsoda.function.visualization.print_emoji_polarization import PrintEmojiPolarization
from parsoda.function.visualization.sort_gap_bide import SortGapBIDE
from parsoda.model.driver.parsoda_multicore_driver import ParsodaMultiCoreDriver
from parsoda.model.driver.parsoda_pycompss_driver import ParsodaPyCompssDriver
from parsoda.model.driver.parsoda_pyspark_driver import ParsodaPySparkDriver
from parsoda.model.driver.parsoda_singlecore_driver import ParsodaSingleCoreDriver
from parsoda.utils.roi import RoI

if __name__ == '__main__':

    #driver = ParsodaSingleCoreDriver()
    driver = ParsodaMultiCoreDriver(4)
    #driver = ParsodaPySparkDriver(SparkConf().setMaster("local[*]"))
    #driver = ParsodaPyCompssDriver()

    app = SocialDataApp("Emoji Polarization", driver)

    app.set_crawlers([
        LocalFileCrawler('../resources/input/TwitterRome2017_100k.json', TwitterParser()),
        LocalFileCrawler('../resources/input/flickr100k.json', FlickrParser())
    ])
    app.set_filters([
        HasEmoji()
    ])
    app.set_mapper(ClassifyByEmoji("../resources/input/emoji.json"))
    app.set_reducer(ReduceByEmojiPolarity())
    app.set_analyzer(TwoFactionsPolarization())
    app.set_visualizer(PrintEmojiPolarization('../resources/output/emoji_polarization.txt'))

    app.execute()
